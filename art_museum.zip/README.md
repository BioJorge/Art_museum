
# Art museum project, PIXIDA application test

This project was design according to the PIXIDA Front-end developer job application test.

To run this project you can use the "On live" VSCode extension or open the file through an internet browser

Inside the Art_museum.rar file, you will find both the html files "art.html" and "index.html". They are the pages developed to mimic the design proposed by Figma file.

I have managed to develop the project besides the integration with the API. When I try to contact the API through my localhost server, it keeps getting access denied due to the CORS policy.I am sending attached in this email my work so far, but I was not able to integrate the project with your API.
